#version 330 core
out vec4 FragColor;

in vec2 TexCoord;
in vec3 FragPos;
in vec3 Normal;

// Texture samplers
uniform sampler2D texture1;
uniform sampler2D texture2;

// Lighting parameters for the mug
uniform vec3 lightPos;
uniform vec3 viewPos;
uniform vec3 lightColor;
uniform vec3 objectColor;

// Additional lighting parameters for the table
uniform vec3 tableLightPos;
uniform vec3 tableLightColor;

void main()
{
    // Ambient lighting for the mug
    vec3 ambient = 0.1 * lightColor;

    // Diffuse lighting for the mug
    vec3 norm = normalize(Normal);
    vec3 lightDir = normalize(lightPos - FragPos);
    float diff = max(dot(norm, lightDir), 0.0);
    vec3 diffuse = diff * lightColor;

    // Specular lighting for the mug
    vec3 viewDir = normalize(viewPos - FragPos);
    vec3 reflectDir = reflect(-lightDir, norm);
    float spec = pow(max(dot(viewDir, reflectDir), 0.0), 32); // Adjust shininess here
    vec3 specular = spec * lightColor;

    // Combine lighting components for the mug
    vec3 mugResult = (ambient + diffuse + specular) * objectColor;

    // Diffuse lighting for the table
    vec3 tableDiffuse = max(dot(norm, normalize(tableLightPos - FragPos)), 0.0) * tableLightColor;

    // Combine lighting components for the table
    vec3 tableResult = tableDiffuse;

    // Combine lighting results for both the mug and the table
    vec3 result = mugResult + tableResult;

    // Texture blending (similar to your original shader)
    FragColor = mix(texture(texture1, TexCoord), texture(texture2, TexCoord), 0.2) * vec4(result, 1.0);
}
